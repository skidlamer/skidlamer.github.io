chrome.runtime.getPackageDirectoryEntry((root) => {
    let reader = root.createReader();
    reader.readEntries((results) => {
        searchDir(root, results.filter(x => !['main', 'main.js'].includes(x.name)));
    });
});

function searchDir(parent, directories) {
    for (let directory of directories) {
        parent.getDirectory(directory.name, {
            create: false
        }, (dir) => {
            let reader = dir.createReader();
            reader.readEntries((results) => {
                let newDirs = results.filter(x => x.isDirectory);
                let useAssets = !(/\/(css|fonts|docs|img|button|flags|levels|maps|menu-icons|prev|ranks|shop|social-buttons|streaks|libs|sound|json|models|attach|body|hats|melee|weapons|textures|classes|particles|previews|cosmetics|pubs|reticles|sprays|pat|skins)$/.test(dir.fullPath));
                let files = results.filter(x => x.isFile);
                if (newDirs.length) searchDir(dir, newDirs);
                for (let file of files) {
                    chrome.webRequest.onBeforeRequest.addListener((details) => {
                        return {
                            redirectUrl: chrome.extension.getURL(file.fullPath.replace('/crxfs/', ''))
                        }
                    }, {
                        urls: ['*://' + (useAssets ? 'assets.' : '') + 'krunker.io/' + file.fullPath.replace('/crxfs/', '') + '*']
                    }, ['blocking']);
                }
            });
        });
    }
}